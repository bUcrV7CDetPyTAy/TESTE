import { useState, useEffect } from 'react';
import { SixPathsOrbs } from '@/components/SixPathsOrbs';
import { SystemIndicators } from '@/components/SystemIndicators';
import { AnimeNewsCard } from '@/components/AnimeNewsCard';
import { GoogleNewsSearch } from '@/components/GoogleNewsSearch';
import { AlphabetFooter } from '@/components/AlphabetFooter';
import { useGoogleNews } from '@/hooks/useGoogleNews';
import {
  RefreshCw,
  ExternalLink,
  BookOpen,
  PlayCircle,
  Star,
  TrendingUp,
  Globe
} from 'lucide-react';

const Index = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isLoaded, setIsLoaded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentQuery, setCurrentQuery] = useState('');
  const { news, loading: newsLoading, error, searchGoogleNews, clearCache } = useGoogleNews();

  useEffect(() => {
    setIsLoaded(true);
    
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleCardClick = (link: string) => {
    window.open(link, '_blank');
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 2000);
  };

  const handleSearch = (query: string, language: string) => {
    setCurrentQuery(query);
    setIsLoading(true);
    searchGoogleNews(query, language).finally(() => {
      setIsLoading(false);
    });
  };

  const handleAlphabetSearch = (letter: string) => {
    const searchTerm = letter.length === 1 ? 
      `anime manga ${letter}*` : 
      letter;
    handleSearch(searchTerm, 'pt');
  };

  // Auto-load default content
  useEffect(() => {
    if (news.length === 0 && !newsLoading) {
      handleSearch('anime manga noticias', 'pt');
    }
  }, []);

  return (
    <div className="min-h-screen bg-background relative overflow-x-hidden">
      {/* Six Paths Orbs */}
      <SixPathsOrbs isLoading={isLoading} cursorPosition={mousePosition} />
      
      {/* System Indicators */}
      <SystemIndicators />
      
      {/* Header */}
      <header className="relative z-20 p-4 md:p-6">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary-glow rounded-full flex items-center justify-center shadow-yellow">
                <Star className="w-6 h-6 text-black" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-primary">Six Paths</h1>
                <p className="text-sm text-primary/70">Global Anime & Manga News Portal</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              {currentQuery && (
                <div className="flex items-center space-x-2 text-primary/60 text-sm">
                  <TrendingUp className="w-4 h-4" />
                  <span className="font-mono">"{currentQuery}"</span>
                </div>
              )}
              
              <button
                onClick={clearCache}
                className="flex items-center space-x-2 px-3 py-2 bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4 text-primary" />
                <span className="text-primary text-sm hidden md:inline">Cache</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section with Search */}
      <section className="relative py-8 md:py-16 px-4 md:px-6">
        <div className="container mx-auto text-center">
          <div className={`space-y-8 transition-all duration-1000 ${
            isLoaded ? 'animate-fade-in-up' : 'opacity-0'
          }`}>
            <div className="space-y-4">
              <h2 className="text-3xl md:text-6xl font-bold text-primary">
                NOTÍCIAS GLOBAIS
              </h2>
              <div className="text-base md:text-xl text-primary/70 font-mono">
                POWERED BY GOOGLE NEWS • REAL-TIME • MULTILINGUAL
              </div>
            </div>
            
            <p className="text-base md:text-lg text-primary/60 max-w-3xl mx-auto leading-relaxed">
              Sistema avançado de busca global conectado ao Google News. 
              Acesse notícias de anime e manga em tempo real de todo o mundo.
            </p>

            {/* Global Search Component */}
            <div className="mt-8">
              <GoogleNewsSearch 
                onSearch={handleSearch}
                isLoading={isLoading || newsLoading}
              />
            </div>
          </div>
        </div>
      </section>

      {/* News Section */}
      <section className="py-8 md:py-12 px-4 md:px-6">
        <div className="container mx-auto">
          {/* Stats Bar */}
          {news.length > 0 && (
            <div className="flex flex-wrap justify-center gap-4 mb-8 p-4 bg-black/50 backdrop-blur-sm rounded-xl border border-primary/30">
              <div className="flex items-center space-x-2">
                <Globe className="w-4 h-4 text-primary" />
                <span className="text-primary font-mono text-sm">{news.length} Notícias</span>
              </div>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                <span className="text-primary font-mono text-sm">Tempo Real</span>
              </div>
              {currentQuery && (
                <div className="flex items-center space-x-2">
                  <Star className="w-4 h-4 text-primary" />
                  <span className="text-primary font-mono text-sm">"{currentQuery}"</span>
                </div>
              )}
            </div>
          )}

          {error && (
            <div className="text-center mb-8 p-4 bg-red-500/20 border border-red-500/50 rounded-lg">
              <p className="text-red-400">Erro: {error}</p>
              <button
                onClick={() => handleSearch(currentQuery || 'anime manga', 'pt')}
                className="mt-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/50 rounded text-red-400 transition-colors"
              >
                Tentar novamente
              </button>
            </div>
          )}

          {(newsLoading || isLoading) ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center space-x-4">
                <RefreshCw className="w-8 h-8 text-primary animate-spin" />
                <span className="text-xl text-primary">Processando busca global...</span>
              </div>
              <p className="text-primary/60 text-sm mt-2">Acessando Google News em tempo real</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {news.map((item, index) => (
                <AnimeNewsCard
                  key={`${item.title}-${index}`}
                  news={{
                    title: item.title,
                    description: item.description,
                    image: item.imageUrl,
                    link: item.url,
                    pubDate: item.publishedAt,
                    source: item.source
                  }}
                  onCardClick={handleCardClick}
                />
              ))}
            </div>
          )}

          {news.length === 0 && !newsLoading && !isLoading && !error && (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 text-primary/50 mx-auto mb-4" />
              <p className="text-xl text-primary">Faça uma pesquisa para começar</p>
              <p className="text-primary/60 text-sm mt-2">Use a busca acima ou o alfabeto abaixo</p>
            </div>
          )}
        </div>
      </section>

      {/* Alphabet Search Footer */}
      <AlphabetFooter onLetterClick={handleAlphabetSearch} />

      {/* Footer */}
      <footer className="py-8 md:py-12 border-t border-primary/30 bg-black/70 backdrop-blur-sm">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Brand */}
            <div className="flex flex-col items-center md:items-start">
              <div className="flex items-center space-x-3 mb-4">
                <Star className="w-8 h-8 text-primary" />
                <div>
                  <div className="text-2xl font-bold text-primary">Six Paths</div>
                  <div className="text-xs text-primary/60">Global News Portal</div>
                </div>
              </div>
              <p className="text-primary/70 text-sm text-center md:text-left">
                Sistema avançado de busca global powered by Google News.
                Notícias de anime e manga em tempo real.
              </p>
            </div>

            {/* Features */}
            <div className="text-center md:text-left">
              <h4 className="text-primary font-mono font-bold mb-4">RECURSOS</h4>
              <ul className="space-y-2 text-primary/70 text-sm">
                <li>• Busca em tempo real</li>
                <li>• Suporte multilíngue</li>
                <li>• Cache inteligente</li>
                <li>• Interface responsiva</li>
                <li>• Sem necessidade de backend</li>
              </ul>
            </div>

            {/* Stats */}
            <div className="text-center md:text-right">
              <h4 className="text-primary font-mono font-bold mb-4">STATUS</h4>
              <div className="space-y-2 text-primary/70 text-sm">
                <div>6 Six Paths Ativos</div>
                <div>∞ Atualizações em tempo real</div>
                <div>24/7 Monitoramento global</div>
                <div>{news.length} Notícias carregadas</div>
              </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-primary/20">
            <div className="text-primary/60 text-sm font-mono mb-4 md:mb-0">
              © 2024 SIX PATHS • POWERED BY GOOGLE NEWS
            </div>
            <div className="flex space-x-4">
              <button className="p-2 text-primary hover:text-primary-glow transition-colors">
                <PlayCircle className="w-5 h-5" />
              </button>
              <button className="p-2 text-primary hover:text-primary-glow transition-colors">
                <BookOpen className="w-5 h-5" />
              </button>
              <button className="p-2 text-primary hover:text-primary-glow transition-colors">
                <ExternalLink className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;


