import { cn } from "@/lib/utils";
import { ReactNode, useState } from "react";

interface HolographicCardProps {
  children: ReactNode;
  className?: string;
  floating?: boolean;
  intense?: boolean;
  style?: React.CSSProperties;
}

export const HolographicCard = ({ 
  children, 
  className, 
  floating = false,
  intense = false,
  style
}: HolographicCardProps) => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setMousePosition({ x, y });
  };

  return (
    <div
      className={cn(
        "holographic-card group relative p-6 transition-all duration-500",
        floating && "animate-floating",
        intense && "hover:scale-105",
        isHovered && "z-20",
        className
      )}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        ...style,
        transform: isHovered 
          ? `perspective(1000px) rotateX(${(mousePosition.y - 150) * 0.1}deg) rotateY(${(mousePosition.x - 150) * 0.1}deg)` 
          : 'none'
      }}
    >
      {/* Holographic overlay */}
      <div 
        className="absolute inset-0 opacity-0 group-hover:opacity-30 transition-opacity duration-500 pointer-events-none"
        style={{
          background: `radial-gradient(circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(0,255,255,0.3) 0%, rgba(255,0,255,0.2) 50%, transparent 70%)`
        }}
      />
      
      {/* Scan lines */}
      <div className="absolute inset-0 scan-lines opacity-0 group-hover:opacity-20 transition-opacity duration-500" />
      
      {/* Border glow */}
      <div className="absolute inset-0 rounded-xl border border-primary/30 group-hover:border-primary/60 transition-colors duration-500" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
      
      {/* Corner accents */}
      <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-secondary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-secondary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </div>
  );
};