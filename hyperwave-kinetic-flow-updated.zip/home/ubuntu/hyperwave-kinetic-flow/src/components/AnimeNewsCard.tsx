import { useState, useEffect } from 'react';

interface NewsItem {
  title: string;
  description: string;
  image?: string;
  link: string;
  pubDate: string;
  source: string;
}

interface AnimeNewsCardProps {
  news: NewsItem;
  onCardClick: (link: string) => void;
}

const getPinterestEmbedUrl = (query: string) => {
  const encodedQuery = encodeURIComponent(query);
  // This is a placeholder. A real implementation would need a backend to fetch random pins or use a Pinterest API.
  // For demonstration, we'll use a generic search URL that might not always return an embeddable pin directly.
  // Pinterest's embed functionality is primarily for specific pins or boards, not dynamic search results for iframes.
  // A more robust solution would involve using a Pinterest API to search for pins and then generate embed codes.
  return `https://www.pinterest.com/search/pins/?q=${encodedQuery}&rs=typed&embed=1`;
};

export const AnimeNewsCard = ({ news, onCardClick }: AnimeNewsCardProps) => {
  const [imageError, setImageError] = useState(false);
  const [pinterestEmbedUrl, setPinterestEmbedUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!news.image) {
      setPinterestEmbedUrl(getPinterestEmbedUrl(news.title));
    }
  }, [news.title, news.image]);

  const handleClick = () => {
    onCardClick(news.link);
  };

  const getDomainFromUrl = (url: string) => {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname.replace('www.', '');
    } catch (e) {
      return 'unknown.com';
    }
  };

  return (
    <div 
      className="bg-card border border-primary/20 rounded-lg overflow-hidden hover:border-primary/50 transition-all duration-300 cursor-pointer group hover:shadow-yellow"
      onClick={handleClick}
    >
      {(news.image && !imageError) ? (
        <div className="aspect-video overflow-hidden">
          <img 
            src={news.image} 
            alt={news.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={() => setImageError(true)}
          />
        </div>
      ) : (pinterestEmbedUrl && (
        <div className="aspect-video overflow-hidden bg-gray-900 flex items-center justify-center">
          <iframe
            src={pinterestEmbedUrl}
            width="100%"
            height="100%"
            frameBorder="0"
            allowFullScreen
            title={`Pinterest image for ${news.title}`}
            className="object-cover"
          ></iframe>
        </div>
      ))}
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-primary font-mono bg-primary/10 px-2 py-1 rounded">
            {news.source}
          </span>
          <span className="text-xs text-muted-foreground">
            {new Date(news.pubDate).toLocaleDateString('pt-BR')}
          </span>
        </div>
        
        <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
          {news.title}
        </h3>
        
        <p className="text-sm text-muted-foreground line-clamp-3">
          {news.description}
        </p>
        
        <div className="mt-3 pt-3 border-t border-primary/10">
          <span className="text-xs text-primary hover:text-primary-glow transition-colors">
            Clique para ler mais →
          </span>
          <div className="text-xs text-primary/60 mt-1">
            By {getDomainFromUrl(news.link)}
          </div>
        </div>
      </div>
    </div>
  );
};

