import { cn } from "@/lib/utils";
import { forwardRef } from "react";

interface CyberButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'destructive';
  size?: 'sm' | 'md' | 'lg';
  glowing?: boolean;
}

const CyberButton = forwardRef<HTMLButtonElement, CyberButtonProps>(
  ({ className, variant = 'primary', size = 'md', glowing = false, ...props }, ref) => {
    const baseClasses = "relative overflow-hidden transition-all duration-300 font-semibold tracking-wider uppercase border-2 group disabled:opacity-50 disabled:cursor-not-allowed";
    
    const variants = {
      primary: "border-primary text-primary hover:text-primary-foreground hover:shadow-neon-intense",
      secondary: "border-secondary text-secondary hover:text-secondary-foreground",
      ghost: "border-transparent text-foreground hover:border-accent hover:text-accent",
      destructive: "border-destructive text-destructive hover:text-destructive-foreground"
    };

    const sizes = {
      sm: "px-4 py-2 text-xs",
      md: "px-6 py-3 text-sm",
      lg: "px-8 py-4 text-base"
    };

    const glowClass = glowing ? "animate-pulse-glow" : "";

    return (
      <button
        ref={ref}
        className={cn(
          baseClasses,
          variants[variant],
          sizes[size],
          glowClass,
          "before:absolute before:inset-0 before:bg-gradient-to-r before:from-primary before:to-secondary before:opacity-0 before:transition-opacity before:duration-300 hover:before:opacity-20",
          "after:absolute after:inset-0 after:border after:border-primary after:opacity-0 after:transition-all after:duration-300 hover:after:opacity-100 hover:after:scale-105",
          className
        )}
        {...props}
      >
        <span className="relative z-10 group-hover:animate-cyber-pulse">
          {props.children}
        </span>
        
        {/* Corner decorations */}
        <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </button>
    );
  }
);

CyberButton.displayName = "CyberButton";

export { CyberButton };