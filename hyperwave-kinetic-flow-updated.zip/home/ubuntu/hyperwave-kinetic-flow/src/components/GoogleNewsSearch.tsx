import { useState, useEffect } from 'react';
import { Search, Globe, Filter } from 'lucide-react';

interface NewsItem {
  title: string;
  description: string;
  url: string;
  source: string;
  publishedAt: string;
  imageUrl?: string;
}

interface GoogleNewsSearchProps {
  onSearch: (query: string, language: string) => void;
  isLoading: boolean;
}

const languages = [
  { code: 'pt', name: 'Português', flag: '🇧🇷' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'ja', name: '日本語', flag: '🇯🇵' },
  { code: 'ko', name: '한국어', flag: '🇰🇷' },
  { code: 'zh', name: '中文', flag: '🇨🇳' }
];

export const GoogleNewsSearch = ({ onSearch, isLoading }: GoogleNewsSearchProps) => {
  const [query, setQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('pt');
  const [showLanguages, setShowLanguages] = useState(false);
  const [suggestions] = useState([
    'Anime', 'Manga', 'One Piece', 'Naruto', 'Attack on Titan',
    'Demon Slayer', 'Dragon Ball', 'My Hero Academia', 'Jujutsu Kaisen',
    'Tokyo Revengers', 'Chainsaw Man', 'Studio Ghibli'
  ]);

  const handleSearch = (searchQuery?: string) => {
    const searchTerm = searchQuery || query;
    if (searchTerm.trim()) {
      onSearch(searchTerm, selectedLanguage);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const currentLanguage = languages.find(lang => lang.code === selectedLanguage);

  return (
    <div className="w-full max-w-4xl mx-auto relative">
      <div className="flex flex-col md:flex-row gap-3 p-4 bg-black/80 backdrop-blur-sm rounded-xl border border-primary/30">
        {/* Language Selector */}
        <div className="relative">
          <button
            onClick={() => setShowLanguages(!showLanguages)}
            className="flex items-center space-x-2 px-4 py-3 bg-primary/20 hover:bg-primary/30 border border-primary/50 rounded-lg transition-colors min-w-[120px]"
          >
            <Globe className="w-4 h-4 text-primary" />
            <span className="text-primary font-mono text-sm">
              {currentLanguage?.flag} {currentLanguage?.code.toUpperCase()}
            </span>
          </button>
          
          {showLanguages && (
            <div className="absolute top-full mt-2 left-0 z-50 bg-black/95 backdrop-blur-sm border border-primary/30 rounded-lg overflow-hidden">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    setSelectedLanguage(lang.code);
                    setShowLanguages(false);
                  }}
                  className="flex items-center space-x-3 w-full px-4 py-3 hover:bg-primary/20 transition-colors text-left"
                >
                  <span className="text-lg">{lang.flag}</span>
                  <span className="text-primary font-mono text-sm">{lang.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Search Input */}
        <div className="flex-1 relative">
          <div className="relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Pesquisar notícias globais..."
              className="w-full px-4 py-3 bg-black/50 border border-primary/30 rounded-lg text-primary placeholder-primary/60 focus:border-primary focus:outline-none"
            />
            <button
              onClick={() => handleSearch()}
              disabled={isLoading}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-primary hover:text-primary-glow transition-colors"
            >
              <Search className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Filter Button */}
        <button className="flex items-center space-x-2 px-4 py-3 bg-primary/20 hover:bg-primary/30 border border-primary/50 rounded-lg transition-colors">
          <Filter className="w-4 h-4 text-primary" />
          <span className="text-primary font-mono text-sm hidden md:inline">Filtros</span>
        </button>
      </div>

      {/* Quick Suggestions */}
      <div className="mt-4 flex flex-wrap gap-2">
        {suggestions.map((suggestion) => (
          <button
            key={suggestion}
            onClick={() => handleSearch(suggestion)}
            className="px-3 py-2 bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded-lg text-primary text-sm transition-colors"
          >
            {suggestion}
          </button>
        ))}
      </div>
    </div>
  );
};