import { useState, useEffect } from 'react';
import { CyberButton } from './CyberButton';
import { GlitchText } from './GlitchText';
import { Zap, Shield, Cpu, Wifi } from 'lucide-react';

export const CyberNavbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    const timeInterval = setInterval(() => {
      setTime(new Date());
    }, 1000);

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
      clearInterval(timeInterval);
    };
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      scrolled 
        ? 'glass-morph backdrop-blur-xl border-b border-primary/30' 
        : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Cpu className="w-8 h-8 text-primary animate-rotate-glow" />
              <div className="absolute inset-0 w-8 h-8 rounded-full bg-primary/20 animate-ping" />
            </div>
            <GlitchText 
              text="HYPER.TECH" 
              className="text-2xl font-bold text-primary"
              continuous
            />
          </div>

          {/* Center Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-foreground hover:text-primary transition-colors duration-300 relative group">
              <span>HOME</span>
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#tech" className="text-foreground hover:text-primary transition-colors duration-300 relative group">
              <span>TECH</span>
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#neural" className="text-foreground hover:text-primary transition-colors duration-300 relative group">
              <span>NEURAL</span>
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300" />
            </a>
            <a href="#quantum" className="text-foreground hover:text-primary transition-colors duration-300 relative group">
              <span>QUANTUM</span>
              <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300" />
            </a>
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* Status Indicators */}
            <div className="hidden lg:flex items-center space-x-3 text-xs">
              <div className="flex items-center space-x-1">
                <Wifi className="w-3 h-3 text-green-400" />
                <span className="text-green-400">ONLINE</span>
              </div>
              <div className="flex items-center space-x-1">
                <Shield className="w-3 h-3 text-blue-400" />
                <span className="text-blue-400">SECURE</span>
              </div>
              <div className="text-primary font-mono">
                {formatTime(time)}
              </div>
            </div>

            {/* Action Button */}
            <CyberButton variant="primary" size="sm" glowing>
              <Zap className="w-4 h-4 mr-2" />
              CONNECT
            </CyberButton>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-background">
          <div 
            className="h-full bg-gradient-to-r from-primary via-secondary to-accent transition-all duration-300"
            style={{
              width: `${Math.min(100, (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100)}%`
            }}
          />
        </div>
      </div>
    </nav>
  );
};