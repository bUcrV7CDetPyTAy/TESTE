import { useEffect, useRef } from 'react';

interface Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
  connections: number[];
}

export const NeuroNetwork = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nodesRef = useRef<Node[]>([]);
  const animationRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      
      // Initialize nodes
      const nodeCount = 50;
      nodesRef.current = Array.from({ length: nodeCount }, (_, i) => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        connections: []
      }));

      // Create connections
      nodesRef.current.forEach((node, i) => {
        const connectionCount = Math.floor(Math.random() * 4) + 1;
        for (let j = 0; j < connectionCount; j++) {
          const targetIndex = Math.floor(Math.random() * nodeCount);
          if (targetIndex !== i && !node.connections.includes(targetIndex)) {
            node.connections.push(targetIndex);
          }
        }
      });
    };

    resize();
    window.addEventListener('resize', resize);

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Update node positions
      nodesRef.current.forEach(node => {
        node.x += node.vx;
        node.y += node.vy;

        // Bounce off edges
        if (node.x <= 0 || node.x >= canvas.width) node.vx *= -1;
        if (node.y <= 0 || node.y >= canvas.height) node.vy *= -1;

        // Keep in bounds
        node.x = Math.max(0, Math.min(canvas.width, node.x));
        node.y = Math.max(0, Math.min(canvas.height, node.y));
      });

      // Draw connections
      nodesRef.current.forEach((node, i) => {
        node.connections.forEach(targetIndex => {
          const target = nodesRef.current[targetIndex];
          if (!target) return;

          const dx = target.x - node.x;
          const dy = target.y - node.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 200) {
            const opacity = (200 - distance) / 200;
            
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(target.x, target.y);
            
            const gradient = ctx.createLinearGradient(node.x, node.y, target.x, target.y);
            gradient.addColorStop(0, `rgba(0, 255, 255, ${opacity * 0.6})`);
            gradient.addColorStop(0.5, `rgba(255, 0, 255, ${opacity * 0.8})`);
            gradient.addColorStop(1, `rgba(255, 255, 0, ${opacity * 0.6})`);
            
            ctx.strokeStyle = gradient;
            ctx.lineWidth = opacity * 2;
            ctx.stroke();

            // Add pulse effect
            if (Math.random() < 0.05) {
              ctx.beginPath();
              ctx.moveTo(node.x, node.y);
              ctx.lineTo(target.x, target.y);
              ctx.strokeStyle = `rgba(255, 255, 255, ${opacity})`;
              ctx.lineWidth = 3;
              ctx.stroke();
            }
          }
        });
      });

      // Draw nodes
      nodesRef.current.forEach((node, i) => {
        // Node glow
        const glowGradient = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, 15);
        glowGradient.addColorStop(0, 'rgba(0, 255, 255, 0.8)');
        glowGradient.addColorStop(0.5, 'rgba(0, 255, 255, 0.3)');
        glowGradient.addColorStop(1, 'rgba(0, 255, 255, 0)');
        
        ctx.beginPath();
        ctx.arc(node.x, node.y, 15, 0, Math.PI * 2);
        ctx.fillStyle = glowGradient;
        ctx.fill();

        // Node core
        ctx.beginPath();
        ctx.arc(node.x, node.y, 3, 0, Math.PI * 2);
        ctx.fillStyle = `hsl(${(i * 30) % 360}, 100%, 70%)`;
        ctx.fill();

        // Node pulse
        if (Math.random() < 0.1) {
          ctx.beginPath();
          ctx.arc(node.x, node.y, 8, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resize);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <div className="relative w-full h-96 overflow-hidden rounded-xl">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ background: 'linear-gradient(135deg, rgba(0,0,0,0.8), rgba(0,50,50,0.4))' }}
      />
      <div className="absolute top-4 left-4 text-primary font-mono text-sm">
        NEURAL NETWORK ACTIVE
      </div>
      <div className="absolute bottom-4 right-4 text-secondary font-mono text-xs">
        50 NODES • {nodesRef.current.reduce((acc, node) => acc + node.connections.length, 0)} CONNECTIONS
      </div>
    </div>
  );
};
