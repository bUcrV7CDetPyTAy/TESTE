import { useState, useEffect, useRef, useCallback } from 'react';

interface Orb {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetX?: number;
  targetY?: number;
  isGathering: boolean;
  onFire: boolean;
  angle: number;
  speed: number;
}

interface SixPathsOrbsProps {
  isLoading?: boolean;
  cursorPosition?: { x: number; y: number };
}

export const SixPathsOrbs = ({ isLoading = false, cursorPosition }: SixPathsOrbsProps) => {
  const [orbs, setOrbs] = useState<Orb[]>([]);
  const animationRef = useRef<number>();
  const containerRef = useRef<HTMLDivElement>(null);
  const lastTimeRef = useRef<number>(0);

  const initializeOrbs = useCallback(() => {
    const initialOrbs: Orb[] = Array.from({ length: 6 }, (_, i) => ({
      id: i,
      x: Math.random() * (window.innerWidth - 100) + 50,
      y: Math.random() * (window.innerHeight - 100) + 50,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      angle: Math.random() * Math.PI * 2,
      speed: 0.5 + Math.random() * 0.5,
      isGathering: false,
      onFire: false
    }));
    setOrbs(initialOrbs);
  }, []);

  useEffect(() => {
    initializeOrbs();
    
    const handleResize = () => {
      initializeOrbs();
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [initializeOrbs]);

  useEffect(() => {
    const animate = (currentTime: number) => {
      const deltaTime = currentTime - lastTimeRef.current;
      // Ensure consistent frame rate, aiming for 60 FPS (1000ms / 60 = 16.67ms per frame)
      if (deltaTime < 1000 / 60) { 
        animationRef.current = requestAnimationFrame(animate);
        return;
      }
      lastTimeRef.current = currentTime;

      setOrbs(prevOrbs => 
        prevOrbs.map(orb => {
          const timeStep = deltaTime * 0.001; // Convert to seconds
          let newX = orb.x;
          let newY = orb.y;
          let newVx = orb.vx;
          let newVy = orb.vy;
          let newAngle = orb.angle;

          if (isLoading && cursorPosition) {
            // Smooth gathering around cursor with orbital motion
            const dx = cursorPosition.x - orb.x;
            const dy = cursorPosition.y - orb.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance > 60) {
              // Move towards cursor smoothly
              const force = Math.min(distance * 0.002, 0.5);
              newVx = (dx / distance) * force;
              newVy = (dy / distance) * force;
            } else {
              // Orbital motion around cursor
              newAngle += 0.03 * timeStep * 60;
              const radius = 45 + Math.sin(currentTime * 0.002 + orb.id) * 10;
              newX = cursorPosition.x + Math.cos(newAngle + orb.id * Math.PI / 3) * radius;
              newY = cursorPosition.y + Math.sin(newAngle + orb.id * Math.PI / 3) * radius;
              newVx = 0;
              newVy = 0;
            }
            
            return {
              ...orb,
              x: newX + newVx * timeStep * 60,
              y: newY + newVy * timeStep * 60,
              vx: newVx,
              vy: newVy,
              angle: newAngle,
              isGathering: true,
              onFire: true
            };
          } else {
            // Smooth wandering with perlin-like movement
            const noiseX = Math.sin(currentTime * 0.001 + orb.id * 2) * 0.3;
            const noiseY = Math.cos(currentTime * 0.0015 + orb.id * 3) * 0.3;
            
            newVx = (newVx + noiseX) * 0.98; // Damping
            newVy = (newVy + noiseY) * 0.98;
            
            // Boundary repulsion with smooth curves
            const margin = 50;
            if (orb.x < margin) newVx += (margin - orb.x) * 0.01;
            if (orb.x > window.innerWidth - margin) newVx -= (orb.x - (window.innerWidth - margin)) * 0.01;
            if (orb.y < margin) newVy += (margin - orb.y) * 0.01;
            if (orb.y > window.innerHeight - margin) newVy -= (orb.y - (window.innerHeight - margin)) * 0.01;
            
            // Speed limiting with smooth transitions
            const speed = Math.sqrt(newVx * newVx + newVy * newVy);
            const maxSpeed = orb.speed;
            if (speed > maxSpeed) {
              newVx = (newVx / speed) * maxSpeed;
              newVy = (newVy / speed) * maxSpeed;
            }
            
            return {
              ...orb,
              x: Math.max(20, Math.min(window.innerWidth - 20, orb.x + newVx * timeStep * 60)),
              y: Math.max(20, Math.min(window.innerHeight - 20, orb.y + newVy * timeStep * 60)),
              vx: newVx,
              vy: newVy,
              angle: newAngle,
              isGathering: false,
              onFire: false
            };
          }
        })
      );
      
      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isLoading, cursorPosition]);

  return (
    <div ref={containerRef} className="fixed inset-0 pointer-events-none z-10">
      {orbs.map(orb => (
        <div
          key={orb.id}
          className={`absolute w-8 h-8 rounded-full transition-all duration-300 ${
            orb.onFire 
              ? 'bg-gradient-to-r from-red-500 via-yellow-500 to-orange-500 animate-pulse shadow-fire' 
              : 'bg-black border-2 border-primary'
          }`}
          style={{
            left: orb.x - 16,
            top: orb.y - 16,
            boxShadow: orb.onFire 
              ? '0 0 30px hsl(0 100% 50% / 0.8), 0 0 60px hsl(30 100% 50% / 0.6)'
              : '0 0 20px hsl(0 0% 0% / 0.9), inset 0 0 10px hsl(60 100% 50% / 0.3)',
            filter: orb.onFire ? 'brightness(1.5)' : 'none',
            // Liquid glass effect
            backdropFilter: 'blur(5px) saturate(180%)',
            WebkitBackdropFilter: 'blur(5px) saturate(180%)',
            backgroundColor: 'rgba(0, 0, 0, 0.2)' // Slightly transparent background
          }}
        />
      ))}
    </div>
  );
};

