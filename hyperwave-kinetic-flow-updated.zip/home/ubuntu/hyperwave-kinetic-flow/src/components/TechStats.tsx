import { useState, useEffect } from 'react';
import { HolographicCard } from './HolographicCard';

interface StatItem {
  label: string;
  value: number;
  unit: string;
  color: string;
}

export const TechStats = () => {
  const [stats, setStats] = useState<StatItem[]>([
    { label: 'CPU USAGE', value: 0, unit: '%', color: 'text-primary' },
    { label: 'MEMORY', value: 0, unit: 'GB', color: 'text-secondary' },
    { label: 'BANDWIDTH', value: 0, unit: 'Mb/s', color: 'text-accent' },
    { label: 'CONNECTIONS', value: 0, unit: '', color: 'text-green-400' }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => prev.map(stat => ({
        ...stat,
        value: Math.random() * (stat.label === 'CONNECTIONS' ? 1000 : 100)
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const getBarWidth = (value: number, max: number = 100) => {
    return (value / max) * 100;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <HolographicCard key={stat.label} className="animate-fade-in-up" style={{ animationDelay: `${index * 0.1}s` }}>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs font-semibold text-muted-foreground tracking-wider">
                {stat.label}
              </span>
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            </div>
            
            <div className="space-y-2">
              <div className={`text-2xl font-bold ${stat.color} font-mono`}>
                {stat.value.toFixed(stat.label === 'CONNECTIONS' ? 0 : 1)}
                <span className="text-sm ml-1">{stat.unit}</span>
              </div>
              
              <div className="relative h-2 bg-background rounded-full overflow-hidden">
                <div 
                  className={`absolute top-0 left-0 h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all duration-1000 ease-out`}
                  style={{ 
                    width: `${getBarWidth(stat.value, stat.label === 'CONNECTIONS' ? 1000 : 100)}%` 
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-pulse" />
              </div>
            </div>
            
            <div className="text-xs text-muted-foreground flex justify-between">
              <span>MIN: 0</span>
              <span>MAX: {stat.label === 'CONNECTIONS' ? '1000' : '100'}</span>
            </div>
          </div>
        </HolographicCard>
      ))}
    </div>
  );
};