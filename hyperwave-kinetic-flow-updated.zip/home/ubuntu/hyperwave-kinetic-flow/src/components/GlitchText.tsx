import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface GlitchTextProps {
  text: string;
  className?: string;
  trigger?: boolean;
  continuous?: boolean;
}

export const GlitchText = ({ 
  text, 
  className, 
  trigger = false, 
  continuous = false 
}: GlitchTextProps) => {
  const [glitched, setGlitched] = useState(false);
  const [displayText, setDisplayText] = useState(text);

  const characters = '!@#$%^&*()_+-=[]{}|;:,.<>?~`0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

  const glitchEffect = () => {
    if (glitched) return;
    
    setGlitched(true);
    let iterations = 0;
    const maxIterations = 10;

    const interval = setInterval(() => {
      setDisplayText(prev => 
        prev.split('').map((char, index) => {
          if (Math.random() < 0.3) {
            return characters[Math.floor(Math.random() * characters.length)];
          }
          return iterations > maxIterations * 0.7 ? text[index] : char;
        }).join('')
      );

      iterations++;
      
      if (iterations >= maxIterations) {
        clearInterval(interval);
        setDisplayText(text);
        setTimeout(() => setGlitched(false), 500);
      }
    }, 50);
  };

  useEffect(() => {
    if (trigger) {
      glitchEffect();
    }
  }, [trigger]);

  useEffect(() => {
    if (continuous) {
      const interval = setInterval(() => {
        if (Math.random() < 0.1) {
          glitchEffect();
        }
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [continuous]);

  return (
    <span 
      className={cn(
        "relative inline-block transition-all duration-100",
        glitched && "animate-cyber-pulse",
        className
      )}
      onMouseEnter={() => !continuous && glitchEffect()}
      style={{
        textShadow: glitched 
          ? '2px 0 #ff0000, -2px 0 #00ffff, 0 2px #ff00ff' 
          : 'none',
        filter: glitched ? 'contrast(1.2) brightness(1.1)' : 'none'
      }}
    >
      {displayText}
      
      {glitched && (
        <>
          <span 
            className="absolute top-0 left-0 text-red-500 opacity-70"
            style={{ transform: 'translate(2px, 0)' }}
          >
            {displayText}
          </span>
          <span 
            className="absolute top-0 left-0 text-cyan-500 opacity-70"
            style={{ transform: 'translate(-2px, 0)' }}
          >
            {displayText}
          </span>
        </>
      )}
    </span>
  );
};