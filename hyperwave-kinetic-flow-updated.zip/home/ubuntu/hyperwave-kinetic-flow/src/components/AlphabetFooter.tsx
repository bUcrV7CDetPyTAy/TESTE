import { useState } from 'react';

interface AlphabetFooterProps {
  onLetterClick: (letter: string) => void;
}

export const AlphabetFooter = ({ onLetterClick }: AlphabetFooterProps) => {
  const [activeLetter, setActiveLetter] = useState<string | null>(null);
  
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  const numbers = '0123456789'.split('');

  const handleLetterClick = (letter: string) => {
    setActiveLetter(letter);
    onLetterClick(letter);
    // Reset active letter after animation
    setTimeout(() => setActiveLetter(null), 300);
  };

  return (
    <div className="w-full bg-black/90 backdrop-blur-sm border-t border-primary/30 py-6">
      <div className="container mx-auto px-4">
        <div className="text-center mb-4">
          <h3 className="text-primary font-mono text-lg mb-2">BUSCA ALFABÉTICA</h3>
          <p className="text-primary/60 text-sm">Clique em uma letra para buscar notícias</p>
        </div>
        
        {/* Alphabet */}
        <div className="flex flex-wrap justify-center gap-1 md:gap-2 mb-4">
          {alphabet.map((letter) => (
            <button
              key={letter}
              onClick={() => handleLetterClick(letter)}
              className={`
                w-8 h-8 md:w-10 md:h-10 
                border border-primary/50 rounded 
                font-mono font-bold text-sm md:text-base
                transition-all duration-200
                ${activeLetter === letter 
                  ? 'bg-primary text-black scale-110 shadow-yellow' 
                  : 'bg-black/50 text-primary hover:bg-primary/20 hover:scale-105'
                }
              `}
            >
              {letter}
            </button>
          ))}
        </div>

        {/* Numbers */}
        <div className="flex flex-wrap justify-center gap-1 md:gap-2 mb-4">
          {numbers.map((number) => (
            <button
              key={number}
              onClick={() => handleLetterClick(number)}
              className={`
                w-8 h-8 md:w-10 md:h-10 
                border border-primary/50 rounded 
                font-mono font-bold text-sm md:text-base
                transition-all duration-200
                ${activeLetter === number 
                  ? 'bg-primary text-black scale-110 shadow-yellow' 
                  : 'bg-black/50 text-primary hover:bg-primary/20 hover:scale-105'
                }
              `}
            >
              {number}
            </button>
          ))}
        </div>

        {/* Popular Categories */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 md:gap-3">
          {[
            'Anime', 'Manga', 'Dragon Ball', 'Naruto', 'One Piece', 'Attack on Titan',
            'Studio Ghibli', 'Pokemon', 'Demon Slayer', 'My Hero Academia', 'Bleach', 'Tokyo Ghoul'
          ].map((category) => (
            <button
              key={category}
              onClick={() => handleLetterClick(category)}
              className="px-3 py-2 bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded text-primary text-xs md:text-sm font-mono transition-colors truncate"
            >
              {category}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};