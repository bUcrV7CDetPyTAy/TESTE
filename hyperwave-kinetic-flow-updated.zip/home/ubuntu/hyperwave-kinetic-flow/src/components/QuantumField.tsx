import { useEffect, useRef } from 'react';

export const QuantumField = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };

    resize();
    window.addEventListener('resize', resize);

    let time = 0;
    const gridSize = 30;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      time += 0.02;

      // Draw quantum field grid
      for (let x = 0; x < canvas.width; x += gridSize) {
        for (let y = 0; y < canvas.height; y += gridSize) {
          const wave1 = Math.sin(x * 0.01 + time) * Math.sin(y * 0.01 + time);
          const wave2 = Math.cos(x * 0.008 + time * 1.5) * Math.cos(y * 0.008 + time * 1.5);
          const wave3 = Math.sin(Math.sqrt((x - canvas.width/2)**2 + (y - canvas.height/2)**2) * 0.005 + time * 2);
          
          const intensity = (wave1 + wave2 + wave3) / 3;
          const normalizedIntensity = (intensity + 1) / 2;
          
          // Quantum particles
          if (normalizedIntensity > 0.7) {
            const size = normalizedIntensity * 4;
            const alpha = normalizedIntensity * 0.8;
            
            // Particle glow
            const glowGradient = ctx.createRadialGradient(x, y, 0, x, y, size * 3);
            glowGradient.addColorStop(0, `rgba(0, 255, 255, ${alpha})`);
            glowGradient.addColorStop(0.5, `rgba(255, 0, 255, ${alpha * 0.5})`);
            glowGradient.addColorStop(1, 'rgba(255, 255, 0, 0)');
            
            ctx.beginPath();
            ctx.arc(x, y, size * 3, 0, Math.PI * 2);
            ctx.fillStyle = glowGradient;
            ctx.fill();

            // Particle core
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
            ctx.fill();

            // Quantum uncertainty visualization
            if (Math.random() < 0.1) {
              const offsetX = (Math.random() - 0.5) * 10;
              const offsetY = (Math.random() - 0.5) * 10;
              
              ctx.beginPath();
              ctx.arc(x + offsetX, y + offsetY, size * 0.5, 0, Math.PI * 2);
              ctx.fillStyle = `rgba(255, 0, 0, ${alpha * 0.5})`;
              ctx.fill();
            }
          }

          // Field lines
          if (x < canvas.width - gridSize && y < canvas.height - gridSize) {
            const nextIntensity = Math.sin((x + gridSize) * 0.01 + time) * Math.sin(y * 0.01 + time);
            const gradient = (nextIntensity - intensity) * 100;
            
            if (Math.abs(gradient) > 0.5) {
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(x + gridSize, y);
              ctx.strokeStyle = `rgba(0, 255, 255, ${Math.abs(gradient) * 0.3})`;
              ctx.lineWidth = Math.abs(gradient) * 2;
              ctx.stroke();
            }
          }
        }
      }

      // Quantum entanglement visualization
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = 100;
      
      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2 + time;
        const x1 = centerX + Math.cos(angle) * radius;
        const y1 = centerY + Math.sin(angle) * radius;
        const x2 = centerX + Math.cos(angle + Math.PI) * radius;
        const y2 = centerY + Math.sin(angle + Math.PI) * radius;
        
        // Entangled particles
        ctx.beginPath();
        ctx.arc(x1, y1, 3, 0, Math.PI * 2);
        ctx.fillStyle = `hsl(${i * 45}, 100%, 70%)`;
        ctx.fill();
        
        ctx.beginPath();
        ctx.arc(x2, y2, 3, 0, Math.PI * 2);
        ctx.fillStyle = `hsl(${i * 45}, 100%, 70%)`;
        ctx.fill();
        
        // Entanglement connection
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = `hsla(${i * 45}, 100%, 70%, 0.3)`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div className="relative w-full h-96 overflow-hidden rounded-xl">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ background: 'radial-gradient(circle, rgba(0,0,50,0.8), rgba(0,0,0,0.9))' }}
      />
      <div className="absolute top-4 left-4 text-accent font-mono text-sm">
        QUANTUM FIELD SIMULATOR
      </div>
      <div className="absolute bottom-4 right-4 text-secondary font-mono text-xs">
        UNCERTAINTY PRINCIPLE ACTIVE
      </div>
    </div>
  );
};