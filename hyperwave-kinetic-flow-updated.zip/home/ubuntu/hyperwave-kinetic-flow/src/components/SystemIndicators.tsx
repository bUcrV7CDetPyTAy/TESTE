import { useState, useEffect } from 'react';
import { Wifi, Clock, HardDrive, Activity } from 'lucide-react';

export const SystemIndicators = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [memoryUsage, setMemoryUsage] = useState<string>('N/A');
  const [networkSpeed, setNetworkSpeed] = useState<{ download: string; upload: string }>({ download: 'N/A', upload: 'N/A' });

  useEffect(() => {
    // Update time every second
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Monitor online status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Get memory usage (if available and supported)
    const updateMemoryUsage = () => {
      if ('performance' in window && 'memory' in performance) {
        const perfMemory = (performance as any).memory;
        const usedJSHeapSizeMB = (perfMemory.usedJSHeapSize / (1024 * 1024)).toFixed(2);
        const totalJSHeapSizeMB = (perfMemory.totalJSHeapSize / (1024 * 1024)).toFixed(2);
        setMemoryUsage(`${usedJSHeapSizeMB}MB / ${totalJSHeapSizeMB}MB`);
      } else {
        setMemoryUsage('Não disponível');
      }
    };

    // Get network speed (if available and supported)
    const updateNetworkSpeed = () => {
      if ('connection' in navigator && (navigator.connection as any).downlink !== undefined) {
        const connection = navigator.connection as any;
        setNetworkSpeed({
          download: `${connection.downlink} Mbps`,
          upload: connection.rtt ? `${connection.rtt} ms (RTT)` : 'N/A'
        });
      } else {
        setNetworkSpeed({ download: 'Não disponível', upload: 'Não disponível' });
      }
    };

    updateMemoryUsage();
    updateNetworkSpeed();

    const memoryInterval = setInterval(updateMemoryUsage, 5000); // Update every 5 seconds
    const networkInterval = setInterval(updateNetworkSpeed, 5000); // Update every 5 seconds

    return () => {
      clearInterval(timeInterval);
      clearInterval(memoryInterval);
      clearInterval(networkInterval);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <>
      {/* Desktop Indicators */}
      <div className="hidden md:block fixed top-4 right-4 z-50 space-y-2">
        {/* Current Time */}
        <div className="flex items-center space-x-2 bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg border border-primary/30">
          <Clock className="w-4 h-4 text-primary" />
          <span className="text-primary font-mono text-sm">
            {formatTime(currentTime)}
          </span>
        </div>

        {/* Internet Status */}
        <div className="flex items-center space-x-2 bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg border border-primary/30">
          <Wifi className={`w-4 h-4 ${isOnline ? 'text-primary' : 'text-red-500'}`} />
          <span className={`font-mono text-sm ${isOnline ? 'text-primary' : 'text-red-500'}`}>
            {isOnline ? 'ONLINE' : 'OFFLINE'}
          </span>
        </div>

        {/* Network Speed */}
        <div className="bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg border border-primary/30">
          <div className="flex items-center space-x-2 mb-1">
            <Activity className="w-4 h-4 text-primary" />
            <span className="text-primary font-mono text-xs">NETWORK</span>
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">↓</span>
              <span className="text-primary font-mono">{networkSpeed.download}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">↑</span>
              <span className="text-primary font-mono">{networkSpeed.upload}</span>
            </div>
          </div>
        </div>

        {/* Memory Usage */}
        <div className="flex items-center space-x-2 bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg border border-primary/30">
          <HardDrive className="w-4 h-4 text-primary" />
          <div className="text-xs">
            <div className="text-primary font-mono">{memoryUsage}</div>
            <div className="text-muted-foreground">RAM</div>
          </div>
        </div>
      </div>

      {/* Mobile Compact Indicators */}
      <div className="md:hidden fixed top-2 right-2 z-50">
        <div className="flex items-center space-x-1 bg-black/90 backdrop-blur-sm px-2 py-1 rounded-lg border border-primary/30">
          <Clock className="w-3 h-3 text-primary" />
          <span className="text-primary font-mono text-xs">
            {formatTime(currentTime).substring(0, 5)}
          </span>
          <div className="w-px h-3 bg-primary/30 mx-1" />
          <Wifi className={`w-3 h-3 ${isOnline ? 'text-primary' : 'text-red-500'}`} />
          <span className={`font-mono text-[10px] ${isOnline ? 'text-primary' : 'text-red-500'}`}>
            {isOnline ? 'ON' : 'OFF'}
          </span>
          <div className="w-px h-3 bg-primary/30 mx-1" />
          <HardDrive className="w-3 h-3 text-primary" />
          <span className="text-primary font-mono text-[10px]">{memoryUsage}</span>
        </div>
      </div>
    </>
  );
};

