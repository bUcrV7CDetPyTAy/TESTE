import { useState, useEffect } from 'react';

interface NewsItem {
  title: string;
  description: string;
  image?: string;
  link: string;
  pubDate: string;
  source: string;
}

export const useAnimeNews = () => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // RSS Feed URLs (CORS-enabled or proxied)
  const RSS_FEEDS = [
    'https://api.rss2json.com/v1/api.json?rss_url=https://feeds.feedburner.com/crunchyroll/animenews',
    'https://api.rss2json.com/v1/api.json?rss_url=https://www.animenewsnetwork.com/all/rss.xml',
  ];

  const fetchNews = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const allNews: NewsItem[] = [];

      for (const feedUrl of RSS_FEEDS) {
        try {
          const response = await fetch(feedUrl);
          const data = await response.json();
          
          if (data.status === 'ok' && data.items) {
            const feedNews = data.items.slice(0, 10).map((item: any) => ({
              title: item.title || 'Sem título',
              description: item.description?.replace(/<[^>]*>/g, '').substring(0, 200) + '...' || 'Sem descrição',
              image: item.enclosure?.link || item.thumbnail || undefined,
              link: item.link || '#',
              pubDate: item.pubDate || new Date().toISOString(),
              source: new URL(feedUrl).hostname.includes('crunchyroll') ? 'Crunchyroll' : 'Anime News Network'
            }));
            
            allNews.push(...feedNews);
          }
        } catch (feedError) {
          console.warn(`Erro ao carregar feed: ${feedUrl}`, feedError);
        }
      }

      // Fallback: Notícias simuladas se não conseguir carregar feeds reais
      if (allNews.length === 0) {
        const mockNews: NewsItem[] = [
          {
            title: 'Novo anime de One Piece revela trailer inédito',
            description: 'A nova temporada promete trazer batalhas épicas e novos personagens que irão surpreender os fãs...',
            link: 'https://example.com/news1',
            pubDate: new Date().toISOString(),
            source: 'Anime News',
            image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=225&fit=crop'
          },
          {
            title: 'Attack on Titan: Mangá chega ao fim após 11 anos',
            description: 'O mangá que conquistou milhões de fãs ao redor do mundo finalmente chega ao seu final emocionante...',
            link: 'https://example.com/news2',
            pubDate: new Date(Date.now() - 3600000).toISOString(),
            source: 'Manga Plus',
            image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=400&h=225&fit=crop'
          },
          {
            title: 'Demon Slayer anuncia nova temporada para 2024',
            description: 'A continuação da história de Tanjiro promete ainda mais ação e momentos emocionantes...',
            link: 'https://example.com/news3',
            pubDate: new Date(Date.now() - 7200000).toISOString(),
            source: 'Crunchyroll',
            image: 'https://images.unsplash.com/photo-1626618012641-bfbca5a31239?w=400&h=225&fit=crop'
          },
          {
            title: 'My Hero Academia: Novo filme ganha data de estreia',
            description: 'O quarto filme da franquia promete explorar novos aspectos dos quirks dos heróis...',
            link: 'https://example.com/news4',
            pubDate: new Date(Date.now() - 10800000).toISOString(),
            source: 'Funimation',
            image: 'https://images.unsplash.com/photo-1612198537852-1d99562b6d3c?w=400&h=225&fit=crop'
          },
          {
            title: 'Jujutsu Kaisen: Mangá retorna após hiato',
            description: 'Após um período de pausa, o mangá volta com novos capítulos cheios de ação e mistério...',
            link: 'https://example.com/news5',
            pubDate: new Date(Date.now() - 14400000).toISOString(),
            source: 'Weekly Shonen Jump',
            image: 'https://images.unsplash.com/photo-1606918801925-e2c914c4b503?w=400&h=225&fit=crop'
          },
          {
            title: 'Chainsaw Man: Segunda parte do mangá surpreende',
            description: 'A continuação da história de Denji traz novos elementos sobrenaturais e personagens cativantes...',
            link: 'https://example.com/news6',
            pubDate: new Date(Date.now() - 18000000).toISOString(),
            source: 'Shonen Jump+',
            image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=225&fit=crop'
          }
        ];
        allNews.push(...mockNews);
      }

      // Ordenar por data mais recente
      const sortedNews = allNews.sort((a, b) => 
        new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime()
      );

      setNews(sortedNews.slice(0, 20)); // Limitar a 20 notícias
    } catch (err) {
      console.error('Erro ao carregar notícias:', err);
      setError('Erro ao carregar notícias');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
    
    // Atualizar notícias a cada 5 minutos
    const interval = setInterval(fetchNews, 300000);
    
    return () => clearInterval(interval);
  }, []);

  return { news, loading, error, refetch: fetchNews };
};